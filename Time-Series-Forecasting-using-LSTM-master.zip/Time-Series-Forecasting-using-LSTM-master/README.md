# Time-Series-Forecasting-using-LSTM
1.Predicting future temperature (using 7 years of weather data ) by making use of time series models like Moving window average and LSTM(single and multi step).

2.Data Link : Max Plank Institute, https://www.bgc-jena.mpg.de/wetter/

3.Built Simple Moving window average and Complex LSTM architecture (LSTM-32 , adam optimizer , over 10 epochs), got an MAE of 0.19.

4.Made use of single(temperature) and multi(temp, pressure, density) features to build the model

